//20.	Write a program to print the output as given under by using escape sequence.   
// C:\Windows>
//'P'     'A'     'K'
//				"Pakistan"
#include<iostream>
#include<string>
using namespace std;
int main()
{
cout<<"C:\\Window>"<<endl;
cout<<" \'P\' \'A\' \'K\'"<<endl;
cout<< "\"Pakistan\""<<endl;
return 0;
}