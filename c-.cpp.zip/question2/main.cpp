//2.	Write a program to print a message "C language is a powerful programing language." on screen.
#include<iostream>
#include<string>
int main()
{
    std::cout<<"C language is most powerfull programming language.";
    return 0;
}
