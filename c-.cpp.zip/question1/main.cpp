//1.	Write a program to assigned values to three variables at the time of declaration. Print the assigned values on the computer screen.
#include<iostream>
#include<string>
int main()
{
    int a, b, c;
    a=10;
    b=30;
    c=50;
    std::cout<<"a="<< a << std::endl;
     std::cout<<"b="<< b << std::endl;
      std::cout<<"c="<< c << std::endl;
      return 0;
}
