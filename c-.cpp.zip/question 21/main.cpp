/***21.	Write a program to print the output as shown below using '\n' escape sequence (without using loop and use one printf statement)
	XXXXX
	XXXX
	XXX
	XX
	X ***/
#include<iostream>
#include<string>
using namespace std;
int main()
{
    cout<<"XXXXX\nXXXX\nXXX\nXX\nX"<<endl;
    return 0;
}
